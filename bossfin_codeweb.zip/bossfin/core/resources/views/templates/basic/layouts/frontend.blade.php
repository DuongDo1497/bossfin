@extends($activeTemplate . 'layouts.app')
@section('panel')
    <div class="page-wrapper">
        @yield('content')
    </div>
@endsection
