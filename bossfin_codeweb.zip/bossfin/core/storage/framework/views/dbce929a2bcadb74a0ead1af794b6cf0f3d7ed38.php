<?php echo  loadExtension('tawk-chat') ?>
<?php echo  loadExtension('google-analytics') ?>
<?php /**PATH C:\xampp\www\bossfin\core\resources\views/partials/plugins.blade.php ENDPATH**/ ?>